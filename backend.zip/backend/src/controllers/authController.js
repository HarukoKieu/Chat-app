import bcrypt from "bcrypt";
import User from "../models/User.js";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import Session from "../models/Session.js";

const ACCESS_TOKEN_TTL = "5m"; // 5 minutes
const REFRESH_TOKEN_TTL = 30 * 24 * 60 * 60 * 1000; // 30 days

export const signUp = async (request, response) => {
  try {
    const { username, password, email, name, surname } = request.body;

    if (!username || !password || !email || !name || !surname) {
      return response.status(400).json({ message: "All fields are required" });
    }

    // check if username already exists
    const existingUserName = await User.findOne({ username });

    if (existingUserName) {
      return response.status(409).json({ message: "Username already exists" });
    }

    // check if email already exists
    const existingEmail = await User.findOne({ email });

    if (existingEmail) {
      return response.status(409).json({ message: "Email already exists" });
    }

    // password encryption
    const hashedPassword = await bcrypt.hash(password, 10);

    // create user
    await User.create({
      username,
      hashedPassword,
      email,
      displayName: `${surname} ${name}`,
    });

    return response.status(201).json({ message: "Signup successful" });
  } catch (error) {
    console.error("Error while calling signUp", error);
    return response.status(500).json({ message: "Internal server error" });
  }
};

export const signIn = async (request, response) => {
  try {
    // get username and password
    const { username, password } = request.body;

    if (!username || !password) {
      return response.status(400).json({ message: "All fields are required" });
    }
    // check if username is valid
    const user = await User.findOne({ username });

    if (!user) {
      return response
        .status(401)
        .json({ message: "Username or password incorrect" });
    }

    // check if password is valid
    const isPasswordValid = await bcrypt.compare(password, user.hashedPassword);

    if (!isPasswordValid) {
      return response
        .status(401)
        .json({ message: "Username or password incorrect" });
    }

    // if username and password are valid, create access token with jwt
    const accessToken = jwt.sign(
      { userId: user._id },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: ACCESS_TOKEN_TTL },
    );

    // create refresh token
    const refreshToken = crypto.randomBytes(64).toString("hex");

    // create session to store refresh token
    await Session.create({
      userId: user._id,
      refreshToken,
      expiresAt: new Date(Date.now() + REFRESH_TOKEN_TTL), // 30 days
    });

    // return refresh token in cookie
    response.cookie("refreshToken", refreshToken, {
      httpOnly: true, // only accessible by server
      secure: true, // only sent over https
      sameSite: "none", // backend and frontend are on different domains
      maxAge: REFRESH_TOKEN_TTL, // 30 days
    });

    // return access token`
    return response
      .status(200)
      .json({ message: `User ${user.displayName} logged in`, accessToken });
  } catch (error) {
    console.error("Error while calling signIn", error);
    return response.status(500).json({ message: "Internal server error" });
  }
};

export const signOut = async (request, response) => {
  try {
    // get refresh token from cookie
    const refreshToken = request.cookies?.refreshToken;

    if (!refreshToken) {
      return response.status(401).json({ message: "Unauthorized" });
    }

    // delete refresh token
    await Session.deleteOne({ refreshToken: refreshToken });

    // delete refresh token from cookie
    response.clearCookie("refreshToken");

    return response.sendStatus(204);
  } catch (error) {
    console.error("Error while calling signOut", error);
    return response.status(500).json({ message: "Internal server error" });
  }
};

// Get access token from refresh token
export const refreshToken = async (request, response) => {
  try {
    // get refresh token from cookie
    const refreshToken = request.cookies?.refreshToken;

    if (!refreshToken) {
      return response.status(401).json({ message: "Refresh token not found" });
    }

    // check if refresh token is valid
    const session = await Session.findOne({ refreshToken: refreshToken });

    if (!session) {
      return response
        .status(403)
        .json({ message: "Refresh token invalid or expired" });
    }

    // check if refresh token is expired
    if (session.expiresAt < Date.now()) {
      return response.status(403).json({ message: "Refresh token expired" });
    }

    // create new access token
    const accessToken = jwt.sign(
      { userId: session.userId },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: ACCESS_TOKEN_TTL },
    );

    return response
      .status(200)
      .json({ message: "Access token refreshed", accessToken });
  } catch (error) {
    console.error("Error while calling refreshToken", error);
    return response.status(500).json({ message: "Internal server error" });
  }
};
